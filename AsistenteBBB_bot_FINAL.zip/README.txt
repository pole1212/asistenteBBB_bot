
🧠 BOT TELEGRAM - AsistenteBBB_bot

🔧 Subida a https://render.com (gratis)

1. Crea cuenta en https://render.com
2. Conecta GitHub y sube estos archivos (main.py, requirements.txt, Procfile)
3. Crea nuevo Web Service (Python 3)
4. Añade variable de entorno si deseas ocultar TOKEN
5. ¡Listo! Tu bot estará en línea 24/7
