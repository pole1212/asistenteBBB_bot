
from telegram import Update
from telegram.ext import Updater, CommandHandler, MessageHandler, Filters, CallbackContext

TOKEN = "7340263262:AAFibn8_IUtBPSr2hFXPwqDPHanaNohsN5U"

# Preguntas y respuestas básicas
RESPUESTAS = {
    "horario": "Estamos disponibles de 9 a 18h (GMT+2), bb 😈.",
    "precio": "Nuestra tarifa base es 50 €/h.",
    "contacto": "Puedes escribir al email hola@tudominio.com.",
}

def start(update: Update, context: CallbackContext):
    update.message.reply_text(
        "¡Hola! Soy tu AsistenteBBB_bot 😈\n"
        "Pregúntame por: " + ", ".join(RESPUESTAS.keys())
    )

def responder(update: Update, context: CallbackContext):
    texto = update.message.text.lower()
    for clave, resp in RESPUESTAS.items():
        if clave in texto:
            return update.message.reply_text(resp)
    update.message.reply_text("Lo siento, no tengo esa respuesta aún 😅.")

def main():
    updater = Updater(TOKEN, use_context=True)
    dp = updater.dispatcher

    dp.add_handler(CommandHandler("start", start))
    dp.add_handler(MessageHandler(Filters.text & ~Filters.command, responder))

    updater.start_polling()
    updater.idle()

if __name__ == "__main__":
    main()
